---
layout: initial
title: "Teaching"
author: "Zhanhong Cheng"
permalink: /teaching/
---
# Teaching at McGill University
- **Guest Lecturer**, Transportation Network Analysis (CIVE 542), Winter 2023, Winter 2024
- **Instructor** (1/3 load), Spatiotemporal Data Mining (CIVE 650), Fall 2023
- **Teaching Assistant**, Spatiotemporal Data Mining (CIVE 650), Fall 2022
- **Teaching Assistant**, Traffic Engineering & Simulation (CIVE 440), Winter 2021, Fall 2021
- **Teaching Assistant**, Sustainable project management (CIVE 324), Winter 2021