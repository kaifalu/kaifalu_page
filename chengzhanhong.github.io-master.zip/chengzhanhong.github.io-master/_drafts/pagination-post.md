---
layout: post
title: "Pagination Post"
author: "Chester"
tags: Tale
---

Here we see **Tale's** pagination feature in action. It is set to 5 posts per page by default. Feel free to change this number in the `_config.yml` file!
